# Datenschutzhinweise und Berechtigungen

Die Erweiterung liest die aktive Seite nur nach einem Klick auf das Symbol oder auf ein BD-Kontextmenü. `activeTab` und `scripting` ermöglichen diese einmalige Extraktion. `contextMenus` zeigt die beiden Rechtsklick-Aktionen. `storage` speichert das Gerätetoken und die verschlüsselte Warteschlange lokal im Erweiterungskontext. Die Host-Berechtigung ist auf den eigenen BD Worker beschränkt. Kein Browserverlauf, kein Zugriff auf alle Seiten, keine Hintergrundanalyse, keine Cookies fremder Seiten und keine fremde Cloud-KI.

An den Worker gehen ein Token mit ausschließlichem Capture-Zweck und verschlüsselte Capture-Daten. Der Worker prüft das Token und vermittelt die verschlüsselte Übergabe. Die Inhalte werden erst im lokalen BD Vault entschlüsselt und dort als Original in der bestehenden Content-Inbox gespeichert. Der eigene Gedanke ist im Originaldatensatz von Quelltext und Screenshot getrennt.

Ein aktueller Seiten-Capture kann den sichtbaren Seitentitel, URL, Domain, Überschrift, begrenzten Textauszug, vorhandene Autoren- und Publikationsmetadaten sowie eine manuell erstellte Screenshot-Aufnahme enthalten. Der Browser beobachtet sonst keine Webseiten. Im Gerätebereich kann die Verbindung widerrufen werden.
