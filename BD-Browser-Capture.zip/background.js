'use strict';
chrome.runtime.onInstalled.addListener(()=>{
  chrome.contextMenus.removeAll(()=>{
    chrome.contextMenus.create({id:'bd-selection',title:'Auswahl an BD Inbox senden',contexts:['selection']});
    chrome.contextMenus.create({id:'bd-page',title:'Seite an BD Inbox senden',contexts:['page']});
  });
  chrome.storage.local.setAccessLevel?.({accessLevel:'TRUSTED_CONTEXTS'});
});
chrome.contextMenus.onClicked.addListener(async(info,tab)=>{
  if(!tab?.id)return;
  await chrome.storage.session.set({contextDraft:{tabId:tab.id,mode:info.menuItemId==='bd-selection'?'selection':'page',selectionText:info.selectionText||'',createdAt:Date.now()}});
  try{await chrome.action.openPopup({windowId:tab.windowId})}
  catch(_){await chrome.windows.create({url:chrome.runtime.getURL('popup.html?context=1'),type:'popup',width:430,height:680})}
});
