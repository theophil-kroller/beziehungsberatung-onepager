# BD Browser Capture 1.0

Die Erweiterung funktioniert in Chrome und aktuellen Chromium-Browsern ab Chrome 127. Für die erste Installation ist kein Chrome Web Store nötig.

1. `BD-Browser-Capture.zip` herunterladen und entpacken.
2. `chrome://extensions` öffnen und den Entwicklermodus aktivieren.
3. **Entpackte Erweiterung laden** wählen und den Ordner mit `manifest.json` auswählen.
4. Im Beziehungsdynamiken Praxis-Cockpit **Einstellungen → Browser Capture → Browser verbinden** öffnen. Der lokale Vault muss entsperrt sein. Der Code gilt fünf Minuten.
5. Auf das BD-Symbol klicken, Code eingeben, dann zur BD-Seite zurückkehren, bis dort „Browser gekoppelt“ steht. Die Erweiterung anschließend erneut öffnen.

Nutzung: Text markieren und per Rechtsklick „Auswahl an BD Inbox senden“ wählen. Alternativ das Symbol anklicken und zwischen Auswahl, Seite und Screenshot wechseln. Vor dem Senden kann ein eigener Gedanke ergänzt werden. Bei fehlender Verbindung bleibt der verschlüsselte Capture in der Erweiterung gespeichert. „Erneut senden“ prüft ausstehende Übertragungen. Nach dem nächsten Öffnen des Praxis-Cockpits und Entsperren des Vault wird der Capture in die lokale Content-Inbox übernommen; erst dann verschwindet er aus der Sendewarteschlange.

„Sicher übertragen“ bedeutet, dass der verschlüsselte Capture beim Relay liegt. Die lokale Übernahme ist ein getrennter Schritt. Das Relay hält ausstehende Captures höchstens 48 Stunden. Die Extension behält deshalb ihre lokale Kopie und sendet nach Ablauf bei Bedarf erneut. Die Capture-ID verhindert Dubletten im lokalen Vault.

Bei widerrufenem Token kann erneut gekoppelt werden. Ausstehende lokale Captures werden auf den neuen Schlüssel umgeschlüsselt. Bei vollem Erweiterungsspeicher wird vor dem Versand ein Fehler gezeigt. Screenshots sind auf den sichtbaren Bereich und maximal rund 2,8 MB begrenzt.

Für den Betrieb müssen `cloudflare-worker/worker.js`, die aktualisierten Admin- und Content-Inbox-Dateien sowie die ZIP-Datei auf dem eigenen Webhosting bereitgestellt sein. Der Worker verwendet die vorhandenen BOOKING-KV- und D1-Bindungen; der lokale Vault ist für die endgültige Ablage nötig. Weder der Worker noch die Erweiterung führen lokale KI aus. Die Erweiterung funktioniert nicht auf geschützten Browserseiten wie `chrome://extensions`.
