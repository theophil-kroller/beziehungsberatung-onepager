Name: Beziehungsdynamiken Browser Capture
Kurzbeschreibung: Ausgewählte Texte, Webseiten und Screenshots bewusst in die persönliche BD Content-Inbox senden.
Beschreibung: Markiere beim Lesen einen Absatz, öffne das BD-Kontextmenü und ergänze optional einen eigenen Gedanken. Oder speichere eine ganze Seite bzw. den sichtbaren Bereich als Screenshot. Die Erweiterung speichert offline eine verschlüsselte Warteschlange und überträgt Captures nach einmaliger Verbindung an deine eigene Beziehungsdynamiken Praxis-Instanz. Die lokale KI und Organisation finden ausschließlich im bestehenden Praxis-System statt. Keine automatische Überwachung des Browserverlaufs.
Distribution: zunächst entpackt; später optional Chrome Web Store (Unlisted). Store-Veröffentlichung ist nicht Teil dieses Builds.
